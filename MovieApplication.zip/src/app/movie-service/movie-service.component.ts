import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-movie-service',
  templateUrl: './movie-service.component.html',
  styleUrls: ['./movie-service.component.css']
})
export class MovieServiceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
