import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-movie-catalog',
  templateUrl: './movie-catalog.component.html',
  styleUrls: ['./movie-catalog.component.css']
})
export class MovieCatalogComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
