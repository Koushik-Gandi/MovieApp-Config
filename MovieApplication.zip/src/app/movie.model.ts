export class Movie {
    movieId: number;
    movieTitle: string;
    releaseYear:number;
    casts:string[];
    rating:number;
}
